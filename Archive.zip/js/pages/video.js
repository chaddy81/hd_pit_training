let Video = React.createClass({});

//export default Video;
