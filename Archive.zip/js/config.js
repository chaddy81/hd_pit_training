var g_scorm_version = "12"; //"2004"  , "12"
//leave the g_bookmark_alert blank if you do not want to confirm a bookmark
var g_bookmark_alert = "";
var g_content_file = "principles.html";
